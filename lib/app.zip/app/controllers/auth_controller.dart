// auth_controller.dart
import 'dart:math';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:logger/logger.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../routes/app_pages.dart';
// Assuming you have a 'NoAccessScreen' or similar
import '../utils/constants.dart';
import '../views/no_access_screen.dart'; // <--- NEW SCREEN IMPORT

class AuthController extends GetxController {
  var isLoading = false.obs;
  var error = ''.obs;
  var logger = Logger();

  final FirebaseAuth auth = FirebaseAuth.instance;

  @override
  void onInit() async{
    super.onInit();
    auth.authStateChanges().listen((User? user) async {
      if (user == null) {
        logger.d('المستخدم غير مسجل الدخول');
        Get.offAllNamed(Routes.LOGIN);
      } else {
        logger.d('المستخدم مسجل الدخول: ${user.uid}');
        bool hasStore = await _checkIfUserHasStore(user.uid);
        if (hasStore) {
          Get.offAllNamed(Routes.DASHBOARD);
        } else {
          // *** CRITICAL CHANGE HERE ***
          // If the user logs in but doesn't have a store,
          // they should be redirected to a screen indicating no access/store assigned.
          Get.offAllNamed(Routes.NO_ACCESS); // <--- NEW ROUTE
        }
      }
    });

    await generateTestStoreForCurrentUser();

  }
  Future<void> generateTestStoreForCurrentUser() async {
    final user = FirebaseAuth.instance.currentUser;

    if (user == null) {
      print('❌ No user logged in.');
      return;
    }

    final uid = user.uid;
    final random = Random();
    final timestamp = DateTime
        .now()
        .millisecondsSinceEpoch;

    final fakeStore = {
      'name': 'Test Store',
      'description': 'Test Description',
      'logo_url': 'https://example.com/logo.png',
      'phone': '1234567890',
      'contact_email': 'test@example.com',
      'city': 'Test City',
      'location': 'Test Location',
      'social': {
        'facebook': 'https://facebook.com/test',
        'instagram': 'https://instagram.com/test',
      },
      'working_hours': {
        'monday': '9am - 5pm',
      },
      'delivery_options': ['pickup', 'delivery'],
      'payment_methods': ['cash', 'credit_card'],
      'announcement_message': 'Big sale today!',
      'announcement_active': true,
      'created_by': 'testUid123',
      'created_at': Timestamp.now(),
      'updated_at': Timestamp.now(),
      'status': 'active',
    };

    try {
      await FirebaseFirestore.instance.collection(AppConstants.storesCollection).add(fakeStore);
      print('✅ Test store added successfully for user $uid');
    } catch (e) {
      print('❌ Failed to add test store: $e');
    }
  }

  Future<bool> _checkIfUserHasStore(String uid) async {
    try {
      final querySnapshot = await FirebaseFirestore.instance
          .collection('stores') // Use 'stores'
          .where('created_by', isEqualTo: uid) // Use 'created_by'
          .limit(1)
          .get();
      return querySnapshot.docs.isNotEmpty;
    } catch (e) {
      logger.e('Error checking for user store: $e');
      return false; // Assume no store on error
    }
  }

  void login(String email, String password) async {
    isLoading.value = true;
    error.value = '';
    try {
      await auth.signInWithEmailAndPassword(email: email, password: password);
      // Navigation is now handled by the authStateChanges listener in onInit
    } on FirebaseAuthException catch (e) {
      error.value = e.message ?? 'حدث خطأ عند تسجيل الدخول';
    } catch (e) {
      error.value = e.toString();
    } finally {
      isLoading.value = false;
    }
  }

  void register(String email, String password) async {
    try {
      isLoading.value = true;
      error.value = '';
      await auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      // After registration, the user is automatically logged in.
      // The authStateChanges listener will trigger, check for store,
      // and then route to NO_ACCESS (since they won't have a store yet).
    } on FirebaseAuthException catch (e) {
      error.value = e.message ?? 'حدث خطأ عند إنشاء الحساب';
    } finally {
      isLoading.value = false;
    }
  }

  void logout() async {
    isLoading.value = true;
    try {
      await auth.signOut();
      // Navigation handled by authStateChanges listener
    } catch (e) {
      logger.e('Error during logout: $e');
    } finally {
      isLoading.value = false;
    }
  }
}